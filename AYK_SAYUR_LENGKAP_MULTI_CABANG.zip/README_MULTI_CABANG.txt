AYK SAYUR - VERSI LENGKAP MULTI CABANG

Isi paket:
- index.html : aplikasi AYK SAYUR multi cabang
- supabase_multicabang.sql : SQL tambahan untuk fitur cabang

Fitur cabang:
1. Admin Pusat dan Admin Cabang.
2. Admin Pusat dapat membuat banyak cabang.
3. Setiap cabang memiliki password admin sendiri.
4. Pembeli memilih cabang sebelum belanja.
5. Harga pusat menjadi harga default semua cabang.
6. Cabang dapat mempunyai harga khusus sendiri.
7. Jika harga khusus dikosongkan, cabang mengikuti harga pusat.
8. Stok setiap cabang terpisah.
9. Pesanan tersimpan dengan cabang tujuan.
10. Admin Pusat melihat semua cabang; Admin Cabang hanya melihat cabangnya.
11. Google Maps lokasi pembeli tetap tersedia.
12. Ongkir, pembayaran, QRIS, bukti pembayaran, status pesanan, WhatsApp, cetak struk, laporan, produk dan paket tetap dipertahankan.

LANGKAH PERTAMA:
1. Buka Supabase > SQL Editor.
2. Jalankan seluruh isi file supabase_multicabang.sql.
3. Setelah Success, baru upload/deploy index.html ke Vercel.

Password:
- Admin Pusat awal: 1234
- Password Admin Cabang dibuat saat cabang ditambahkan oleh Admin Pusat.

Catatan:
Versi ini memakai Supabase langsung dari browser seperti versi AYK SAYUR sebelumnya. Untuk keamanan tingkat produksi yang lebih tinggi, autentikasi admin sebaiknya nanti dipindahkan ke Supabase Auth/Backend.
